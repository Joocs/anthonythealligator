import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    alligator Anthony = new alligator();
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        super(1000, 600, 1); 
        
        addObject(Anthony, 500, 300);
        for (int counter = 0; counter < 30; counter = counter + 1) {
            orange fruit = new orange();
            int x = Greenfoot.getRandomNumber(1000);
            int y = Greenfoot.getRandomNumber(600);
            addObject(fruit, x, y);
        }
        for (int counter = 0; counter < 10; counter = counter + 1) {
            obstacle barrel = new obstacle();
            int x = Greenfoot.getRandomNumber(1000);
            int y = Greenfoot.getRandomNumber(600);
            addObject(barrel, x, y);
        }
    }
public void act() {
    showText(Anthony.getScore(),  500, 25);
    showText(Anthony.getLives(),  50, 575);
    
}
}


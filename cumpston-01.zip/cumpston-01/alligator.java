import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class alligator here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class alligator extends Actor
{
    int score = 0;
    int lives=  3;
    /**
     * Act - do whatever the alligator wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        if (Greenfoot.isKeyDown("right") ) {
            turn (1);
        }
        if (Greenfoot.isKeyDown("left") ) {
            turn (-1);
        }
        if (Greenfoot.isKeyDown("up") ) {
            move (1);
        }
        if (Greenfoot.isKeyDown("down") ) {
            move (-1);
        }
        if ( isTouching(orange.class) ) {
            removeTouching(orange.class);
            score = score + 1;
        }
        if ( isAtEdge() ) {
            turn(160);
            move(1);
        } else {
            move(1);
        }
        if ( isTouching(obstacle.class) ) {
            removeTouching(obstacle.class);
            lives = lives - 1;
            setLocation(500, 300);
        } else {
            move(1);
        }
    }    
    public boolean isGameOver() {
        if (lives == 0) {
            return true;
        } else {
            return false;
        }
    }
    public String getScore(){ 
        return "SCORE: " + score;}
    public String getLives(){
        return "LIVES:" + lives;}
    }